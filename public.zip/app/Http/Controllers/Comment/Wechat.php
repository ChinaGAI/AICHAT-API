<?php

namespace App\Http\Controllers\Comment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use EasyWeChat\OfficialAccount\Application;
use Yansongda\LaravelPay\Facades\Pay;

class Wechat extends Controller
{
    public function demo(request $request)
    {
                $order = [
            'out_trade_no' => '96a97f07-19a4-4ce9-8e7c-195023bd1c5f',
            'description' => '支付会员',
            'amount' => [
                'total' => 500,
            ],
        ];
//        $order = [
//            'out_trade_no' => time().'123',
//            'description' => '会员支付',
//            'amount' => [
//                'total' => 2,
//            ],
//            'scene_info' => [
//                'payer_client_ip' => '183.195.88.178',
//                'h5_info' => [
//                    'type' => 'Wap',
//                ]
//            ],
//        ];
        return Pay::wechat()->scan($order);
//        $config = [
//            'app_id' => 'wxa9e675325ed4693a',
//            'secret' => 'fe3a0ee7dff6c4dc177366c922a895dc',
//            'token' => '7d4fce4f5ab3d0790f0fe3e4ae7712cd',
//            'aes_key' => 'FdPh2FDIqNhvbm9jNZjQaRNL3UU6RzKGRM1JHnpt16r' // 明文模式请勿填写 EncodingAESKey
//            //...
//        ];
//
//        $app = new Application($config);
//        $data = $app->getAccessToken();
//        dd($data);
//        $response = $app->getClient()->get("/cgi-bin/user/info?openid={$openid}&lang=zh_CN");
//
//        var_dump($response->toArray());
    }
}
