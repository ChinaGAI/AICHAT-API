![chinaG](https://chat.aieo.cn/_next/image?url=%2Flogo.png&w=96&q=75)
## 需要的环境 PHP8.1+Mysql8+ngnix （当前框架是laravel10）
## AI Chat是什么?
一个对接各大平台语言模型的AI助手
这里就不过多叙述了下面开始写搭建教程
### 问题反馈
在使用中有任何问题，欢迎反馈给我，可以用以下联系方式跟我交流
* QQ群:143559505
* 邮箱:cgp.chinag.pro@gmail.com
### 您可能需要的
[教程直通](https://doc.aieo.cn)    [官网直达](https://chat.aieo.cn)


